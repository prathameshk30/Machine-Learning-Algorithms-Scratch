# CS5783-Assignment-3-Neural-Network

Coding Neural Network from scratch using back propogation.
