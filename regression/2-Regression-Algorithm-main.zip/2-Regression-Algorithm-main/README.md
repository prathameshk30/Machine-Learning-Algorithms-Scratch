# CS5783-Assignment-01-linear-Regression


Coding linear regression algorithm from scratch using gradient descent. 
