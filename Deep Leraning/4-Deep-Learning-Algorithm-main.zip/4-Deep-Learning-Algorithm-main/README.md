# CS5783-Assigment-3-Deep_Learning-CNN

Coding a CNN architecture from scratch.
