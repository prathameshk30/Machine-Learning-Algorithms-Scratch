# CS5783-Assigment-6

OpenCV and Kmeans algorithm fromm scratch.
