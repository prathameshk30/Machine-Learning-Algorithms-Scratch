# CS5783_Assignment-4-KNN-Naive_Bayes

Coding  KNN, Naive Bayes algorithm from scratch.
